const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Configurar a conexão com o banco de dados SQLite
const db = new sqlite3.Database('./database.db');

// Rota para a página inicial
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Rota para gerar frases
// Rota para gerar frases
app.post('/gerar-frase', async (req, res) => {
    try {
        // Obter uma frase aleatória do Kanye West
        const response = await axios.get('https://api.kanye.rest/');
        const novaFrase = response.data.quote;

        // Inserir a nova frase no banco de dados
        db.run('INSERT INTO frases (frase) VALUES (?)', [novaFrase], (err) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            // Retornar a nova frase gerada
            res.status(201).json({ message: 'Frase adicionada com sucesso.', novaFrase });
        });
    } catch (error) {
        console.error('Erro ao obter frase do Kanye:', error.message);
        res.status(500).json({ error: 'Erro ao obter frase do Kanye.' });
    }
});


// Rota para mostrar frases
app.get('/mostrar-frases', (req, res) => {
    // Selecionar todas as frases do banco de dados
    db.all('SELECT * FROM frases', (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json({ frases: rows });
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
